package com.capgemini.UI;

	import org.springframework.beans.factory.BeanFactory;  
	import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;  
	import org.springframework.core.io.Resource;

import com.capgemini.model.Customer;  
	  
	
	public class Test {  
	public static void main(String[] args) {  
		
		
			ApplicationContext context =new ClassPathXmlApplicationContext("ApplicationContext.xml");
			Customer c=(Customer)context.getBean("customer1");
			c.display(); 
	 

//	    Resource r=new ClassPathResource("ApplicationContext.xml");  
//	    
//		BeanFactory factory=new XmlBeanFactory(r);  
//	      
//	    Customer c=(Customer)factory.getBean("customer1");  
//	    c.display();  
	      
	}  
	}  