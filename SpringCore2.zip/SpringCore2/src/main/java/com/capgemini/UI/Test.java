package com.capgemini.UI;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.model.Question;

public class Test {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");

    	Question cust = (Question)context.getBean("QuestionBean");
    	System.out.println(cust);
    	

	}

}
